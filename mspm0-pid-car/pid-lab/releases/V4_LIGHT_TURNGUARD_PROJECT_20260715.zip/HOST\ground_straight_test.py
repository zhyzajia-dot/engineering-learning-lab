"""Safe, logged ground straight-line validation for the MSPM0 car."""

from __future__ import annotations

import argparse
import csv
import json
import statistics
import time
from datetime import datetime
from pathlib import Path

import serial


RAMP_MS = 1500
MM_PER_COUNT = 0.580
GIMBAL_PROFILE_ID = 1
FLASH_PROFILE_VERSION = 3


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Logged V4_GIMBAL ground straight identification. Mechanical, "
            "power, and sensor-height metadata are mandatory."
        )
    )
    parser.add_argument("port", help="PC-side ESP8266/CH340 serial port")
    parser.add_argument("--speed", type=int, choices=(120, 160, 200), default=120)
    parser.add_argument("--duration-ms", type=int, default=3500)
    parser.add_argument("--confirm-ground-clear", action="store_true")
    parser.add_argument("--confirm-observer-ready", action="store_true")
    parser.add_argument("--previous-speed-passed", action="store_true")
    parser.add_argument(
        "--allow-unknown-measurements", action="store_true",
        help="record unavailable numeric load measurements as null",
    )
    parser.add_argument("--base-mass-g", type=float)
    parser.add_argument("--gimbal-mass-g", type=float)
    parser.add_argument("--mounting-mass-g", type=float)
    parser.add_argument("--total-mass-g", type=float)
    parser.add_argument("--gimbal-cog-height-mm", type=float)
    parser.add_argument("--gimbal-cog-forward-mm", type=float)
    parser.add_argument("--gimbal-cog-left-mm", type=float)
    parser.add_argument("--battery-idle-v", type=float)
    parser.add_argument("--battery-startup-v", type=float)
    parser.add_argument("--sensor-height-mm", type=float)
    parser.add_argument("--sensor-height-light-mm", type=float)
    parser.add_argument(
        "--wheel-load",
        choices=("balanced", "left-compressed", "right-compressed", "both-compressed"),
        required=True,
    )
    parser.add_argument(
        "--wheel-slip-observed", choices=("none", "left", "right", "both"),
        required=True,
    )
    parser.add_argument("--confirm-gimbal-mount-rigid", action="store_true")
    parser.add_argument("--notes", default="")
    args = parser.parse_args(argv)
    if not args.confirm_ground_clear:
        parser.error("add --confirm-ground-clear after physically clearing the track")
    if not args.confirm_observer_ready:
        parser.error(
            "add --confirm-observer-ready when someone can stop the car on "
            "slip, tilt, gimbal motion, line loss, or link loss"
        )
    if not args.confirm_gimbal_mount_rigid:
        parser.error("tighten the gimbal mount, then add --confirm-gimbal-mount-rigid")
    if args.wheel_slip_observed != "none":
        parser.error("resolve observed wheel slip before running identification")
    if args.speed > 120 and not args.previous_speed_passed:
        parser.error(
            "160/200 mm/s requires --previous-speed-passed after reviewing "
            "the preceding speed log"
        )
    if not RAMP_MS + 500 <= args.duration_ms <= 15000:
        parser.error(f"duration must be {RAMP_MS + 500}..15000 ms")
    required_measurements = {
        "base-mass-g": args.base_mass_g,
        "gimbal-mass-g": args.gimbal_mass_g,
        "total-mass-g": args.total_mass_g,
        "gimbal-cog-height-mm": args.gimbal_cog_height_mm,
        "gimbal-cog-forward-mm": args.gimbal_cog_forward_mm,
        "gimbal-cog-left-mm": args.gimbal_cog_left_mm,
        "battery-idle-v": args.battery_idle_v,
        "battery-startup-v": args.battery_startup_v,
        "sensor-height-mm": args.sensor_height_mm,
    }
    missing = [
        name for name, value in required_measurements.items() if value is None
    ]
    if missing and not args.allow_unknown_measurements:
        parser.error(
            "missing load measurements: " + ", ".join(missing) +
            "; measure them or add --allow-unknown-measurements"
        )
    if not args.allow_unknown_measurements and args.mounting_mass_g is None:
        args.mounting_mass_g = 0.0
    positive = {
        "base-mass-g": args.base_mass_g,
        "gimbal-mass-g": args.gimbal_mass_g,
        "total-mass-g": args.total_mass_g,
        "gimbal-cog-height-mm": args.gimbal_cog_height_mm,
        "battery-idle-v": args.battery_idle_v,
        "battery-startup-v": args.battery_startup_v,
        "sensor-height-mm": args.sensor_height_mm,
    }
    if args.sensor_height_light_mm is not None:
        positive["sensor-height-light-mm"] = args.sensor_height_light_mm
    for name, value in positive.items():
        if value is not None and value <= 0:
            parser.error(f"{name} must be positive")
    if args.mounting_mass_g is not None and args.mounting_mass_g < 0:
        parser.error("mounting-mass-g must be non-negative")
    mass_values = (
        args.base_mass_g, args.gimbal_mass_g, args.mounting_mass_g,
        args.total_mass_g,
    )
    if all(value is not None for value in mass_values):
        expected_mass = (
            args.base_mass_g + args.gimbal_mass_g + args.mounting_mass_g
        )
        mass_error = args.total_mass_g - expected_mass
        mass_tolerance = max(5.0, expected_mass * 0.02)
        if abs(mass_error) > mass_tolerance:
            parser.error(
                "mass check failed: total differs from base + gimbal + mounting "
                f"by {mass_error:.1f} g (allowed ±{mass_tolerance:.1f} g)"
            )
    if (args.battery_idle_v is not None and
            not 1.0 <= args.battery_idle_v <= 30.0):
        parser.error("battery-idle-v must be 1..30 V")
    if (args.battery_startup_v is not None and
            not 1.0 <= args.battery_startup_v <= 30.0):
        parser.error("battery-startup-v must be 1..30 V")
    if (args.battery_idle_v is not None and
            args.battery_startup_v is not None and
            args.battery_startup_v > args.battery_idle_v + 0.1):
        parser.error("battery-startup-v cannot exceed idle voltage by more than 0.1 V")
    return args


def build_load_metadata(args: argparse.Namespace) -> dict[str, object]:
    mass_components = (
        args.base_mass_g, args.gimbal_mass_g, args.mounting_mass_g,
    )
    expected_mass = (
        sum(mass_components) if all(value is not None for value in mass_components)
        else None
    )
    mass_error = (
        args.total_mass_g - expected_mass
        if args.total_mass_g is not None and expected_mass is not None else None
    )
    return {
        "control_profile": "V4_GIMBAL",
        "profile_id": GIMBAL_PROFILE_ID,
        "measurement_status": (
            "partial_unknowns_allowed" if args.allow_unknown_measurements
            else "complete"
        ),
        "mass_g": {
            "base": args.base_mass_g,
            "gimbal": args.gimbal_mass_g,
            "mounting_hardware": args.mounting_mass_g,
            "total_measured": args.total_mass_g,
            "component_sum": expected_mass,
            "balance_error": mass_error,
        },
        "gimbal_cog_mm": {
            "height_above_ground": args.gimbal_cog_height_mm,
            "forward_from_vehicle_center": args.gimbal_cog_forward_mm,
            "left_from_vehicle_center": args.gimbal_cog_left_mm,
        },
        "power_v": {
            "battery_idle": args.battery_idle_v,
            "battery_two_wheel_startup": args.battery_startup_v,
            "startup_drop": (
                args.battery_idle_v - args.battery_startup_v
                if args.battery_idle_v is not None and
                args.battery_startup_v is not None else None
            ),
        },
        "grayscale_board_height_mm": {
            "gimbal_loaded": args.sensor_height_mm,
            "light_reference": args.sensor_height_light_mm,
            "loaded_minus_light": (
                args.sensor_height_mm - args.sensor_height_light_mm
                if args.sensor_height_mm is not None and
                args.sensor_height_light_mm is not None else None
            ),
        },
        "wheel_load_observation": args.wheel_load,
        "wheel_slip_observed_before_run": args.wheel_slip_observed,
        "gimbal_mount_rigid_confirmed": args.confirm_gimbal_mount_rigid,
        "notes": args.notes,
    }


def parse_parameter_report(lines: list[str]) -> dict[str, int]:
    for line in reversed(lines):
        if not line.startswith("PARAM,"):
            continue
        parts = line.split(",")
        values: dict[str, int] = {}
        for index in range(2, len(parts) - 1, 2):
            try:
                values[parts[index]] = int(parts[index + 1])
            except ValueError:
                continue
        return values
    return {}


def wrapped_yaw_delta(start: int, end: int) -> int:
    delta = end - start
    while delta > 1800:
        delta -= 3600
    while delta < -1800:
        delta += 3600
    return delta


def main() -> int:
    args = parse_args()
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    output_dir = Path(__file__).resolve().parent / "logs" / f"straight_{stamp}"
    output_dir.mkdir(parents=True, exist_ok=False)
    trace_path = output_dir / "protocol_trace.log"
    sample_path = output_dir / "straight_samples.csv"
    summary_path = output_dir / "summary.json"
    metadata_path = output_dir / "load_metadata.json"
    load_metadata = build_load_metadata(args)
    metadata_path.write_text(
        json.dumps(load_metadata, ensure_ascii=False, indent=2), encoding="utf-8"
    )

    link: serial.Serial | None = None
    rx_buffer = b""
    trace_rows: list[str] = []
    samples: list[dict[str, int | str]] = []
    final_stop_confirmed = False

    def trace(direction: str, text: str) -> None:
        row = f"{datetime.now().isoformat(timespec='milliseconds')} {direction} {text}"
        trace_rows.append(row)
        print(row)

    def send(command: str) -> None:
        assert link is not None
        trace("TX", command)
        link.write((command + "\r\n").encode("ascii"))
        link.flush()

    def receive(seconds: float) -> list[str]:
        nonlocal rx_buffer
        assert link is not None
        deadline = time.monotonic() + seconds
        result: list[str] = []
        while time.monotonic() < deadline:
            data = link.read(512)
            if not data:
                time.sleep(0.004)
                continue
            rx_buffer += data
            while b"\n" in rx_buffer:
                raw, rx_buffer = rx_buffer.split(b"\n", 1)
                text = raw.rstrip(b"\r").decode("ascii", "replace").strip()
                if text:
                    result.append(text)
                    trace("RX", text)
        return result

    def command(text: str, wait: float = 0.8) -> list[str]:
        send(text)
        return receive(wait)

    def imu_yaw(lines: list[str]) -> int | None:
        for line in lines:
            if line.startswith("IMU,OK,"):
                return int(line.split(",")[2])
        return None

    try:
        link = serial.Serial(args.port, 115200, timeout=0.03, write_timeout=1)
        time.sleep(0.3)
        link.reset_input_buffer()

        stop_lines = command("STOP")
        profile_lines = command("PROFILE GIMBAL")
        parameter_lines = command("PARAM")
        parameters = parse_parameter_report(profile_lines + parameter_lines)
        status_lines = command("STATUS")
        sensor_lines = command("SENSOR")
        imu_before_lines = command("IMU")
        yaw_before = imu_yaw(imu_before_lines)
        gates = {
            "stop": "OK STOP" in stop_lines,
            "profile": "OK PROFILE GIMBAL FLASH 3" in profile_lines,
            "profile_readback": (
                parameters.get("PROFILE") == GIMBAL_PROFILE_ID and
                parameters.get("FLASHVER") == FLASH_PROFILE_VERSION
            ),
            "idle": any(",IDLE," in line and ",STBY,HIGH" in line
                        for line in status_lines if line.startswith("STATUS,")),
            "sensor": any(line.startswith("SENSOR,OK,") for line in sensor_lines),
            "imu": yaw_before is not None,
        }
        if not all(gates.values()):
            raise RuntimeError(f"preflight failed; RUN not sent: {gates}")

        send(f"RUN {args.speed} {args.duration_ms}")
        run_lines = receive((args.duration_ms / 1000.0) + 1.1)
        for line in run_lines:
            if not line.startswith("PID,"):
                continue
            fields = line.split(",")
            if len(fields) != 19 or fields[2] != "RUN":
                continue
            try:
                samples.append({
                    "time_ms": int(fields[1]),
                    "mode": fields[2],
                    "left_target": int(fields[3]),
                    "right_target": int(fields[4]),
                    "left_speed": int(fields[5]),
                    "right_speed": int(fields[6]),
                    "left_pwm": int(fields[7]),
                    "right_pwm": int(fields[8]),
                    "count_diff": int(fields[11]),
                })
            except ValueError:
                continue

        stop_after = command("STOP")
        final_stop_confirmed = "OK STOP" in stop_after
        imu_after_lines = command("IMU")
        yaw_after = imu_yaw(imu_after_lines)
        if not final_stop_confirmed:
            raise RuntimeError("final STOP was not confirmed")
        if len(samples) < 20:
            raise RuntimeError(f"only {len(samples)} valid RUN samples received")

        steady = [
            row for row in samples
            if RAMP_MS + 200 <= int(row["time_ms"]) <= args.duration_ms - 50
        ]
        if len(steady) < 20:
            raise RuntimeError(f"only {len(steady)} steady samples received")

        def values(key: str) -> list[int]:
            return [int(row[key]) for row in steady]

        ordered = sorted(samples, key=lambda row: int(row["time_ms"]))
        distance = 0.0
        for previous, current in zip(ordered, ordered[1:]):
            dt = max(0, int(current["time_ms"]) - int(previous["time_ms"])) / 1000.0
            previous_speed = (int(previous["left_speed"]) + int(previous["right_speed"])) / 2.0
            current_speed = (int(current["left_speed"]) + int(current["right_speed"])) / 2.0
            distance += (previous_speed + current_speed) * 0.5 * dt

        last = ordered[-1]
        summary = {
            "timestamp": datetime.now().isoformat(timespec="seconds"),
            "load_metadata": load_metadata,
            "runtime_parameters": parameters,
            "port": args.port,
            "speed_command_mmps": args.speed,
            "duration_ms": args.duration_ms,
            "sample_count": len(samples),
            "steady_sample_count": len(steady),
            "left_target_mean_mmps": statistics.mean(values("left_target")),
            "right_target_mean_mmps": statistics.mean(values("right_target")),
            "left_speed_mean_mmps": statistics.mean(values("left_speed")),
            "right_speed_mean_mmps": statistics.mean(values("right_speed")),
            "left_speed_ripple_sd_mmps": statistics.pstdev(values("left_speed")),
            "right_speed_ripple_sd_mmps": statistics.pstdev(values("right_speed")),
            "left_pwm_mean": statistics.mean(values("left_pwm")),
            "right_pwm_mean": statistics.mean(values("right_pwm")),
            "final_count_diff": int(last["count_diff"]),
            "final_distance_diff_mm": int(last["count_diff"]) * MM_PER_COUNT,
            "integrated_average_distance_mm": distance,
            "yaw_before_x10": yaw_before,
            "yaw_after_x10": yaw_after,
            "yaw_delta_x10": (wrapped_yaw_delta(yaw_before, yaw_after)
                               if yaw_before is not None and yaw_after is not None else None),
            "test_done_seen": "TEST DONE" in run_lines,
            "final_stop_confirmed": final_stop_confirmed,
        }
        with sample_path.open("w", newline="", encoding="utf-8") as stream:
            writer = csv.DictWriter(stream, fieldnames=list(samples[0]))
            writer.writeheader()
            writer.writerows(samples)
        summary_path.write_text(
            json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8"
        )
        print("\nSUMMARY")
        print(json.dumps(summary, indent=2))
        print(f"Saved to {output_dir}")
        return 0
    finally:
        if link is not None and link.is_open:
            try:
                if not final_stop_confirmed:
                    send("STOP")
                    final_stop_confirmed = "OK STOP" in receive(0.8)
            finally:
                link.close()
        trace_path.write_text("\n".join(trace_rows) + "\n", encoding="utf-8")


if __name__ == "__main__":
    raise SystemExit(main())

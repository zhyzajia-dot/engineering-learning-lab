param(
    [string]$OutputHex = (Join-Path $PSScriptRoot 'Debug\pid_lab_mspm0_v4_turnguard_rebuilt.hex')
)

$ErrorActionPreference = 'Stop'
$expectedSha256 = 'E8EA86F3A9CD9BA089644B90D8C7E6922221B08E38C6136FD7068A4648A36A93'

& (Join-Path $PSScriptRoot 'build_mspm0_hex.ps1') `
    -OutputHex $OutputHex `
    -Defines 'LAB_ENABLE_DUAL_PROFILE=0'
if ($LASTEXITCODE -ne 0) {
    throw 'V4 LIGHT firmware build failed'
}

$actualSha256 = (Get-FileHash -Algorithm SHA256 -LiteralPath $OutputHex).Hash
if ($actualSha256 -ne $expectedSha256) {
    throw "V4 LIGHT SHA-256 mismatch: $actualSha256"
}

$info = Get-Item -LiteralPath $OutputHex
Write-Host "V4 LIGHT verified: $($info.FullName) ($($info.Length) bytes)"
Write-Host "SHA-256: $actualSha256"

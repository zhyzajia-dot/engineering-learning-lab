"""Command-line acceptance runner for the MSPM0 PID car.

This module deliberately reuses SerialLink and AutoTuner from the GUI so the
visible and headless workflows exercise the same protocol and algorithms.
Motion commands require an explicit physical-safety acknowledgement.
"""

from __future__ import annotations

import argparse
import queue
import sys
import time
from datetime import datetime
from pathlib import Path

from serial.tools import list_ports

from pid_autotune_gui import (
    FIRMWARE_DEFAULT_PARAMETERS,
    PROFILE_IDS,
    TURN_RUNTIME_PARAMETERS,
    AutoTuner,
    SerialLink,
    format_parameters,
)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="MSPM0 PID car GUI-core acceptance CLI"
    )
    subparsers = parser.add_subparsers(dest="command", required=True)
    subparsers.add_parser("ports", help="list available serial ports")

    for name, help_text in (
        ("diagnose", "run HELLO/STATUS/SENSOR/IMU/RADIOPING/PARAM checks"),
        ("params", "read current runtime parameters"),
        ("restore-line", "restore and save the stable LINEKP/LINEKD defaults"),
        ("restore-v4", "restore and save the proven V4 line/turn baseline"),
        ("stop", "send an immediate STOP and wait for confirmation"),
    ):
        command = subparsers.add_parser(name, help=help_text)
        command.add_argument("--port", required=True)

    profile = subparsers.add_parser(
        "profile", help="select and verify the isolated LIGHT/GIMBAL RAM slot"
    )
    profile.add_argument("--port", required=True)
    profile.add_argument(
        "--name", required=True, choices=("light", "gimbal")
    )

    wheel = subparsers.add_parser(
        "wheel-tune", help="run wheel MIN/FF/PI autotuning"
    )
    wheel.add_argument("--port", required=True)
    wheel.add_argument(
        "--wheels", choices=("both", "left", "right"), default="both"
    )
    wheel.add_argument(
        "--wheels-raised", action="store_true",
        help="required acknowledgement that both drive wheels are suspended",
    )

    line = subparsers.add_parser(
        "line-tune", help="run closed-track LINEKP/LINEKD autotuning"
    )
    line.add_argument("--port", required=True)
    line.add_argument(
        "--track-safe", action="store_true",
        help="required acknowledgement that the car is on a closed safe track",
    )

    square = subparsers.add_parser(
        "square", help="run and log a counter-clockwise square"
    )
    square.add_argument("--port", required=True)
    square.add_argument("--speed", type=int, default=340)
    square.add_argument("--laps", type=int, default=1)
    square.add_argument("--turn-angle", type=int, default=900)
    square.add_argument("--turn-fast", type=int, default=185)
    square.add_argument("--turn-slow", type=int, default=140)
    square.add_argument("--turn-margin", type=int, default=180)
    square.add_argument("--turn-exit", type=int, default=140)
    square.add_argument("--turn-distance", type=int, default=98)
    square.add_argument("--timeout", type=float, default=180.0)
    square.add_argument(
        "--track-safe", action="store_true",
        help="required acknowledgement that the car is on a closed safe track",
    )
    return parser


def make_tuner(link: SerialLink) -> tuple[AutoTuner, queue.Queue[str]]:
    statuses: queue.Queue[str] = queue.Queue()
    return AutoTuner(link, statuses, lambda: None), statuses


def connect(port: str) -> SerialLink:
    link = SerialLink()
    link.connect(port)
    # Allow the USB bridge startup banner and any reset noise to finish.
    time.sleep(0.8)
    return link


def print_statuses(statuses: queue.Queue[str]) -> list[str]:
    lines: list[str] = []
    while True:
        try:
            line = statuses.get_nowait()
        except queue.Empty:
            return lines
        lines.append(line)
        print(line)


def request(tuner: AutoTuner, command: str, prefix: str) -> str:
    tuner.link.drain_data()
    reply = tuner._request_with_retry(
        command, lambda item: item.startswith(prefix), command
    )
    if reply is None:
        raise RuntimeError(f"No {prefix} reply for {command}")
    return reply


def run_diagnostics(tuner: AutoTuner) -> None:
    tuner._verify_connection()
    tuner._stop_reliably()
    print(request(tuner, "STATUS", "STATUS,"))
    sensor = request(tuner, "SENSOR", "SENSOR,")
    imu = request(tuner, "IMU", "IMU,")
    tuner.link.drain_data()
    tuner.link.send("RADIOPING")
    radio_replies: set[str] = set()
    deadline = time.monotonic() + 2.0
    while time.monotonic() < deadline and len(radio_replies) < 2:
        try:
            line = tuner.link.data_queue.get(timeout=0.1)
        except queue.Empty:
            continue
        if line in ("BRIDGE_RADIO_PONG", "BRIDGE_RADIO_TX_OK"):
            radio_replies.add(line)
        elif line == "BRIDGE_RADIO_TX_FAILED":
            raise RuntimeError("ESP-NOW bridge reported RADIO TX failure")
    if radio_replies != {"BRIDGE_RADIO_PONG", "BRIDGE_RADIO_TX_OK"}:
        raise RuntimeError(
            "Incomplete RADIOPING result: " +
            (", ".join(sorted(radio_replies)) or "timeout")
        )
    parameters = tuner._read_parameters()
    print(sensor)
    print(imu)
    print("RADIOPING " + ", ".join(sorted(radio_replies)))
    print("PARAM " + format_parameters(parameters))
    if not sensor.startswith("SENSOR,OK,"):
        raise RuntimeError(f"Line sensor check failed: {sensor}")
    if not imu.startswith("IMU,OK,"):
        raise RuntimeError(f"IMU check failed: {imu}")


def run_tune(tuner: AutoTuner, statuses: queue.Queue[str], mode: str,
             wheels: tuple[str, ...] = ()) -> bool:
    if mode == "wheel":
        tuner.start(wheels)
    else:
        tuner.start_line()
    final_lines: list[str] = []
    while tuner.running:
        final_lines.extend(print_statuses(statuses))
        time.sleep(0.1)
    final_lines.extend(print_statuses(statuses))
    return any(
        line.startswith(("COMPLETE:", "LINE COMPLETE:"))
        for line in final_lines
    )


def select_light_profile_if_supported(tuner: AutoTuner) -> None:
    """Select LIGHT on Flash V3 while remaining compatible with archived V4."""
    parameters = tuner._read_parameters()
    flash_version = parameters.get("FLASHVER")
    profile = parameters.get("PROFILE")
    if flash_version == 3:
        tuner._select_profile("LIGHT")
    elif flash_version is not None or profile is not None:
        raise RuntimeError(
            f"Unsupported profile metadata: FLASHVER={flash_version}, "
            f"PROFILE={profile}"
        )


def restore_stable_line(tuner: AutoTuner) -> None:
    """Restore the known-stable line pair without starting either motor."""
    expected = {
        "LINEKP": int(FIRMWARE_DEFAULT_PARAMETERS["LINEKP"]),
        "LINEKD": int(FIRMWARE_DEFAULT_PARAMETERS["LINEKD"]),
    }
    tuner._verify_connection()
    tuner._stop_reliably()
    select_light_profile_if_supported(tuner)
    for name, value in expected.items():
        tuner._send_set(name, value)
    tuner._save_parameters()
    actual = tuner._read_parameters()
    mismatch = {
        name: actual.get(name)
        for name, value in expected.items()
        if actual.get(name) != value
    }
    if mismatch:
        raise RuntimeError(
            f"LINE parameter readback mismatch: expected={expected}, actual={mismatch}"
        )
    print(
        f"OK restored and saved LINEKP={expected['LINEKP']}, "
        f"LINEKD={expected['LINEKD']}"
    )


def restore_v4_baseline(tuner: AutoTuner) -> None:
    """Restore the proven V4 line gains and turn-distance baseline safely."""
    expected = {
        "LINEKP": int(FIRMWARE_DEFAULT_PARAMETERS["LINEKP"]),
        "LINEKD": int(FIRMWARE_DEFAULT_PARAMETERS["LINEKD"]),
        "TURNDIST": int(FIRMWARE_DEFAULT_PARAMETERS["TURNDIST"]),
    }
    tuner._verify_connection()
    tuner._stop_reliably()
    select_light_profile_if_supported(tuner)
    for name, value in expected.items():
        tuner._send_set(name, value)
    tuner._save_parameters()
    actual = tuner._read_parameters()
    mismatch = {
        name: actual.get(name)
        for name, value in expected.items()
        if actual.get(name) != value
    }
    if mismatch:
        raise RuntimeError(
            f"V4 baseline readback mismatch: expected={expected}, "
            f"actual={mismatch}"
        )
    print(
        "OK restored and saved V4 baseline: "
        f"LINEKP={expected['LINEKP']}, LINEKD={expected['LINEKD']}, "
        f"TURNDIST={expected['TURNDIST']}"
    )


def validate_square(args: argparse.Namespace) -> None:
    if not 80 <= args.speed <= 450 or not 1 <= args.laps <= 10:
        raise ValueError("speed must be 80..450 and laps must be 1..10")
    if not 700 <= args.turn_angle <= 1100:
        raise ValueError("turn-angle must be 700..1100")
    if not 100 <= args.turn_fast <= 300:
        raise ValueError("turn-fast must be 100..300")
    if not 80 <= args.turn_slow <= min(250, args.turn_fast):
        raise ValueError("turn-slow must be 80..250 and <= turn-fast")
    if not 50 <= args.turn_margin <= 350:
        raise ValueError("turn-margin must be 50..350")
    if not 80 <= args.turn_exit <= 250:
        raise ValueError("turn-exit must be 80..250")
    if not 50 <= args.turn_distance <= 140:
        raise ValueError("turn-distance must be 50..140")
    if args.timeout <= 0:
        raise ValueError("timeout must be positive")


def run_square(tuner: AutoTuner, args: argparse.Namespace) -> None:
    validate_square(args)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    session = Path(__file__).parent / "logs" / f"square_cli_{stamp}"
    session.mkdir(parents=True, exist_ok=True)
    tuner.link.set_trace_path(session / "protocol_trace.log")
    snapshot: dict[str, int] | None = None
    committed = False
    try:
        tuner._verify_connection()
        tuner._stop_reliably()
        snapshot = tuner._read_parameters()
        sensor = request(tuner, "SENSOR", "SENSOR,")
        imu = request(tuner, "IMU", "IMU,")
        if not sensor.startswith("SENSOR,OK,"):
            raise RuntimeError(f"Line sensor is not ready: {sensor}")
        if not imu.startswith("IMU,OK,"):
            raise RuntimeError(f"IMU is not ready: {imu}")

        # Lower TURNSLOW first so cross-field validation cannot reject a
        # legitimate new TURNFAST/TURNSLOW pair because of the old pair.
        for name, value in (
            ("TURNSLOW", 80), ("TURNFAST", args.turn_fast),
            ("TURNSLOW", args.turn_slow), ("TURNANGLE", args.turn_angle),
            ("TURNMARGIN", args.turn_margin), ("TURNEXIT", args.turn_exit),
            ("TURNDIST", args.turn_distance),
        ):
            tuner._send_set(name, value)

        tuner._start_square_reliably(args.speed, args.laps)
        print(f"SQUARE running at {args.speed} mm/s for {args.laps} lap(s)")
        deadline = time.monotonic() + args.timeout
        while time.monotonic() < deadline:
            try:
                line = tuner.link.data_queue.get(timeout=0.1)
            except queue.Empty:
                continue
            if line.startswith("SQUARE LEARNED,TURNDIST,"):
                print(line)
            if line.startswith("SQUARE DONE"):
                tuner._save_parameters()
                committed = True
                print(f"{line}; parameters saved; trace={session}")
                return
            if line.startswith(("SQUARE ERROR", "ERR SQUARE")):
                raise RuntimeError(line)
        raise TimeoutError(f"SQUARE did not finish within {args.timeout:g}s")
    finally:
        if not committed:
            try:
                tuner.link.send("STOP")
            except Exception:
                pass
            if snapshot is not None:
                try:
                    tuner._restore_runtime_parameters(
                        snapshot, TURN_RUNTIME_PARAMETERS
                    )
                    print(
                        "Square parameters restored in RAM; host SAVE was not "
                        "confirmed (firmware may autosave after SQUARE DONE)"
                    )
                except Exception as exc:
                    print(f"WARNING: square rollback failed: {exc}", file=sys.stderr)


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    if args.command == "ports":
        for port in list_ports.comports():
            print(f"{port.device}\t{port.description}")
        return 0
    if args.command == "wheel-tune" and not args.wheels_raised:
        print("Refusing motion: pass --wheels-raised after suspending both wheels",
              file=sys.stderr)
        return 2
    if args.command in ("line-tune", "square") and not args.track_safe:
        print("Refusing motion: pass --track-safe on a closed safe track",
              file=sys.stderr)
        return 2

    link: SerialLink | None = None
    tuner: AutoTuner | None = None
    try:
        link = connect(args.port)
        tuner, statuses = make_tuner(link)
        if args.command == "diagnose":
            run_diagnostics(tuner)
        elif args.command == "params":
            tuner._verify_connection()
            print(format_parameters(tuner._read_parameters()))
        elif args.command == "restore-line":
            restore_stable_line(tuner)
        elif args.command == "restore-v4":
            restore_v4_baseline(tuner)
        elif args.command == "stop":
            tuner._stop_reliably()
            print("OK STOP")
        elif args.command == "profile":
            tuner._verify_connection()
            tuner._stop_reliably()
            values = tuner._select_profile(args.name)
            selected = args.name.upper()
            if values.get("PROFILE") != PROFILE_IDS[selected]:
                raise RuntimeError(f"Profile verification failed: {values}")
            print(f"OK PROFILE {selected}; " + format_parameters(values))
        elif args.command == "wheel-tune":
            wheel_map = {
                "both": ("L", "R"), "left": ("L",), "right": ("R",),
            }
            return 0 if run_tune(
                tuner, statuses, "wheel", wheel_map[args.wheels]
            ) else 1
        elif args.command == "line-tune":
            return 0 if run_tune(tuner, statuses, "line") else 1
        elif args.command == "square":
            run_square(tuner, args)
        return 0
    except KeyboardInterrupt:
        if tuner is not None:
            tuner.cancel()
        print("Interrupted; STOP sent", file=sys.stderr)
        return 130
    except Exception as exc:
        if tuner is not None:
            tuner.cancel()
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1
    finally:
        if link is not None:
            link.close()


if __name__ == "__main__":
    raise SystemExit(main())

# MSPM0 循迹小车：V4 基线与重云台适配交接

> 更新时间：2026-07-15。新对话先完整阅读本文件，再查看源代码和保留日志。当前工作的唯一控制基线是 V4；不要恢复已经否决的中间循迹实验，也不要在没有实车证据时同时改轮速环、循迹环和转弯状态机。

## 1. 当前结论

- 轻载/原车状态下，截图所指的 V4 已在 `300 / 340 / 380 mm/s` 各完成一圈，用户评价整体可用，380 仍有轻微晃动。
- 当前源代码是 **V4 循迹控制原样 + 最小 TurnGuard + LIGHT/GIMBAL 双参数档基础设施**。双档和日志改动不改变普通直线循迹 PD；原 V4-TurnGuard 固件已经单独保留，随时可回退。
- V4-TurnGuard 在 300 mm/s 完成过一圈，平均绝对循迹误差 `1.411`、P95 `6`。
- 用户随后给车安装了一个很重的云台，明确反馈 V4 已不能正常工作。重载会同时改变轮速响应、可用加速度、轮胎附着、重心和转弯惯量，因此下一步必须建立独立的重载参数档，不能覆盖轻载 V4 基线，也不能只盲调循迹 `Kp/Kd`。
- **目前仍没有“重云台已标定可用”的 HEX。** 当前 HEX 只建立了独立 `V4_GIMBAL` 槽和 120 mm/s 安全采集入口；GIMBAL 槽初值与 V4 相同，仅是未标定起点。装着重云台时不要直接从 300～380 mm/s 开始测试。
- 第 8 路灰度传感器已继续屏蔽：有效掩码为 `0x7F`。这是已知硬件约束，不要重新启用第 8 路。

## 2. 当前固件与两个回退件

| 文件 | 用途 | 大小 | SHA-256 |
| --- | --- | ---: | --- |
| `Debug/pid_lab_mspm0.hex` | 当前双档固件：V4-TurnGuard 控制不变，增加 Flash V3 `LIGHT/GIMBAL` 隔离与重载采集支持 | 90,485 B | `B59DA8C7BEB6D740B520E1090105A060198C4498C952AB5A9FA5006B22FDEDDD` |
| `Debug/pid_lab_mspm0_v4_turnguard.hex` | 修改前已验证的轻载 V4-TurnGuard 回退件 | 87,405 B | `E8EA86F3A9CD9BA089644B90D8C7E6922221B08E38C6136FD7068A4648A36A93` |
| `Debug/pid_lab_mspm0_v4_exact.hex` | 截图版本的精确 V4 回退件；没有 50° 转弯保护 | 87,158 B | `39AB0AF11D68C6541B7C159AD4590EF7AFE632C9B79B4F9DA43B3ED5CF7B5AA1` |

不要再根据文件名猜版本，烧录前用 PowerShell 校验：

```powershell
Get-FileHash -Algorithm SHA256 .\Debug\pid_lab_mspm0.hex
Get-FileHash -Algorithm SHA256 .\Debug\pid_lab_mspm0_v4_turnguard.hex
Get-FileHash -Algorithm SHA256 .\Debug\pid_lab_mspm0_v4_exact.hex
```

普通烧录后，Flash 中已有的运行参数可能不会被 HEX 覆盖。连接上位机后必须执行一次 `restore-v4`，它会先显式选择 `LIGHT`，再写入、保存并回读 V4 的 `LINEKP / LINEKD / TURNDIST`：

```powershell
python .\HOST\pid_lab_cli.py restore-v4 --port COM12
```

把 `COM12` 换成实际串口。只有命令最后明确报告回读一致，才算恢复完成。

## 3. V4 基线参数

以下既是 `app_config.h` 的默认值，也是 `restore-v4` 应恢复到 `LIGHT` 的基线。修改源码默认值不会自动覆盖芯片里已经有效的 Flash 参数。Flash V3 分别保存两套完整参数和当前档位；旧 V1/V2 数据加载时作为 `LIGHT` 保留，下一次 `SAVE` 才迁移为 V3。新建的 `GIMBAL` 槽最初复制这些数值，但后续 `SAVE` 只更新当前槽，不会覆盖另一槽。

| 参数 | 数值 | 含义 |
| --- | ---: | --- |
| `LKP / LKI` | `350 / 100` | 左轮 PI，系数按 x1000 |
| `RKP / RKI` | `500 / 350` | 右轮 PI，系数按 x1000 |
| `LFF / RFF` | `460 / 437` | 左右轮前馈，按 x1000 |
| `LMIN / RMIN` | `32 / 26` | 最小有效 PWM |
| `SYNC / BIAS` | `1000 / 50` | 直线同步与右轮目标补偿 |
| `LINEKP / LINEKD` | `6750 / 2000` | V4 循迹 PD，按 x1000 |
| `TURNANGLE` | `900` | 90.0° |
| `TURNFAST / TURNSLOW` | `185 / 140` | 转弯快、慢段 PWM |
| `TURNMARGIN` | `180` | 距目标 18.0° 切换慢转 |
| `TURNEXIT` | `140` | 出弯目标速度 mm/s |
| `TURNDIST` | `98` | V4 基准转弯里程 mm |

编码器换算为 `0.580 mm/count`，控制采样周期为 `10 ms`。硬件接线、器件规格、I²C 地址和原始资料位置见 [`docs/HARDWARE_REFERENCES.md`](docs/HARDWARE_REFERENCES.md)。

## 4. 当前 V4 控制到底包含什么

### 4.1 直线循迹

V4 直线循迹代码位于 `LAB/lab_ctrl.c`：

- 高速分界为 `340 mm/s`；
- 高速中心/中区/远区修正上限为 `45 / 90 / 125 mm/s`；
- 中心/中区/远区修正变化率为 `5 / 8 / 18 mm/s` 每控制周期；
- `abs(error) <= 4` 为中心区，`abs(error) <= 2` 时关闭 D 项；
- `abs(error) >= 10` 为远区；
- 公共目标速度保持不变，没有主动共模降速，所以已消除此前的顿感来源；
- 有效灰度通道掩码为 `0x7F`，第 8 路不参与误差计算和丢线判断。

### 4.2 唯一附加的 TurnGuard

精确 V4 只要转弯里程超过 `TURNDIST / 2`，看到灰度线就可能提前结束转弯。实车日志证明它曾在 38.8° 和 34.9° 捕获旧边，随后车头方向错误而丢线。

控制算法中的 V4-TurnGuard 只增加：

- IMU 可靠时，偏航角没有达到 50.0° 前禁止灰度提前捕线；
- IMU 不可靠时，至少走到预计转弯里程的 3/4 才允许灰度捕线；
- 90° 目标、快慢转 PWM、循迹 PD、轮速 PI 和编码器滤波均未因这个保护改变。

对应常量是 `LAB_TURN_LINE_CAPTURE_MIN_YAW_X10 = 500`。

当前双档固件另外只增加参数存储和选择机制：`PROFILE LIGHT` / `PROFILE GIMBAL` 在电机空闲时切换槽位；切档会丢弃当前槽未 `SAVE` 的试验值；`PARAM` 用数值字段 `PROFILE=0/1` 和 `FLASHVER=3` 提供回读。它没有调整 V4 的循迹区间、增益、限幅、TurnGuard 或第 8 路掩码。

## 5. 实车证据

保留日志只包含可复现基线、故障定位和最新状态；大量重复试跑与已否决调参日志已经删除。

| 日志 | 固件/速度 | 结果 | 关键数据 |
| --- | --- | --- | --- |
| `HOST/logs/square_20260715_070335` | 精确 V4，300 | 完成 4 弯 | 均值 `3.433`，P95 `9` |
| `HOST/logs/square_20260715_070408` | 精确 V4，340 | 完成 4 弯 | 均值 `3.360`，P95 `18` |
| `HOST/logs/square_20260715_070438` | 精确 V4，380 | 完成 4 弯 | 均值 `3.916`，P95 `6`；用户仍感觉轻微晃动 |
| `HOST/logs/square_20260715_080531` | 精确 V4，300 | 2 弯后丢线 | 定位到约 38.8° 提前捕获旧边 |
| `HOST/logs/square_20260715_080558` | 精确 V4，300 | 3 弯后丢线 | 定位到约 34.9° 提前捕获旧边 |
| `HOST/logs/square_20260715_082029` | V4-TurnGuard，300 | 完成 4 弯 | 均值 `1.411`，P95 `6`，学习里程 `90 mm` |
| `HOST/logs/square_20260715_082445` | 当前代码，340 | 起步后丢线 | 均值 `8.017`，P95 `30` |
| `HOST/logs/square_20260715_082505` | 当前代码，300 | 1 弯后丢线 | 均值 `9.566`，P95 `30` |
| `HOST/logs/square_20260715_082526` | 当前代码，300 | 起步后丢线 | 均值 `5.321`，P95 `25` |

最后三份历史日志本身没有记录是否安装云台，不能仅凭文件断言载荷状态；但用户的实车观察已经明确确认“安装重云台后 V4 不行”。这些历史文件不补写猜测值。新的落地直线日志会在驱动车轮前写入独立 `load_metadata.json`，并在 `summary.json` 中重复保存同一份载荷快照。

另外保留：

- `HOST/logs/20260715_022256`：当前轻载轮速参数的完整调参依据；
- `HOST/logs/imu_manual_synced_20260715_033241`：静态 IMU 基线；
- `HOST/logs/imu_motor_20260715_032546`：电机运行时 IMU/通信基线。

## 6. 重云台适配：下一步正确顺序

重云台不是简单的“循迹 Kp 太小”。它至少改变四件事：同一 PWM 下的轮速与加速时间、左右轮负载差、横摆响应、急转时的附着和侧翻风险。必须保留轻载档，并新增 `V4_GIMBAL` 档。

### 阶段 A：先记录机械与供电条件

开始写控制代码前记录：

1. 原车总质量、云台质量、安装后总质量；
2. 云台重心离地高度、相对车体中心的前后和左右偏移；
3. 电池静置电压，以及两轮启动时是否明显掉压；
4. 左右轮是否压紧、打滑，灰度板离地高度是否因载荷变化；
5. 云台是否能相对车体摆动。若机械安装有松动，控制器无法消除由载荷摆动产生的蛇形。

### 阶段 B：低速重载辨识，不覆盖 V4

- 已建立明确的 `LIGHT` 和 `GIMBAL` 参数档，Flash V3 保存两套完整参数和当前档位；
- 旧 Flash V1/V2 参数只迁移为 `LIGHT`；`GIMBAL` 初值虽与 V4 相同，但必须视为“尚未辨识”，不能称为重载参数；
- `PROFILE LIGHT/GIMBAL` 只在空闲时切档，`SAVE` 只更新当前档，切档前未保存的试验值不会串到另一档；
- 重载辨识先检查轮速前馈、最小 PWM、左右偏差和加速斜坡；
- 现有“悬空轮自动调参”不能代表重载落地后的滚阻与附着，不能直接拿它覆盖重载参数；
- 先在清空的直线场地依次测试 `120 → 160 → 200 mm/s`，每档通过后再升速；
- 任何失线、轮胎打滑、车体明显侧倾、云台摆动或串口断联都立即停止。

已有低速直线记录工具可作为第一轮数据采集入口：

```powershell
python .\HOST\ground_straight_test.py COM12 `
  --speed 120 --duration-ms 3500 `
  --base-mass-g BASE_G --gimbal-mass-g GIMBAL_G `
  --mounting-mass-g MOUNT_G --total-mass-g TOTAL_G `
  --gimbal-cog-height-mm COG_HEIGHT_MM `
  --gimbal-cog-forward-mm COG_FORWARD_MM `
  --gimbal-cog-left-mm COG_LEFT_MM `
  --battery-idle-v BATTERY_IDLE_V `
  --battery-startup-v BATTERY_STARTUP_V `
  --sensor-height-mm SENSOR_HEIGHT_MM `
  --sensor-height-light-mm LIGHT_SENSOR_HEIGHT_MM `
  --wheel-load balanced `
  --wheel-slip-observed none `
  --confirm-gimbal-mount-rigid `
  --confirm-ground-clear --confirm-observer-ready
```

把全大写占位值替换为实测数值；前/左偏移为正，后/右偏移为负。工具会核对总质量与部件和、记录启动压降及灰度板高度，强制选择并回读 `GIMBAL + Flash V3` 后才允许 `RUN`。输出目录包含 `load_metadata.json`、`straight_samples.csv`、`summary.json` 和协议 trace。160/200 mm/s 还必须显式带 `--previous-speed-passed`，表示已经审阅前一速度日志。

若首次 120 mm/s 检查暂时无法取得数值，可以明确把缺失项记录为 `null`，不能填写猜测值：

```powershell
python .\HOST\ground_straight_test.py COM12 `
  --speed 120 --duration-ms 3500 `
  --allow-unknown-measurements `
  --wheel-load balanced --wheel-slip-observed none `
  --confirm-gimbal-mount-rigid `
  --confirm-ground-clear --confirm-observer-ready `
  --notes "gimbal separate battery; powered and stabilized; COG center-forward"
```

它只用于安全采集，不等于自动生成重载参数，也不会修改 `LINEKP/LINEKD`。必须先审阅 120 mm/s 的左右稳态速度、纹波、PWM、里程差、偏航和压降，再决定 GIMBAL 槽内的轮速参数修改。

### 阶段 C：轮速稳定后再改循迹与转弯

- 先让左右实际速度在重载下连续、无停顿、无明显偏航，再调整循迹；
- 循迹需要按误差区间和速度做平滑增益/限幅调度，使小误差稳定、大误差仍有足够修正，不能在阈值处突然翻倍；
- 优先限制修正变化率和目标加速度，避免重心高时左右目标瞬间反向；
- 转弯参数独立重定：`TURNFAST/TURNSLOW/TURNMARGIN/TURNEXIT/TURNDIST` 不能沿用轻载经验后直接高速跑；
- 保留 TurnGuard，但 50° 只是一道早捕线保护，不是重载转弯已经完成的证明；
- 自动调参必须使用完整四边、失败回滚和显式保存，候选参数不得在失败后残留。

建议验收顺序为：重载直线 120、重载方框 120、160、200，各速度连续多圈无失线后才考虑更高速度。不要一开始追求 380 mm/s。

## 7. 上位机和终端入口

首次安装依赖：

```powershell
python -m pip install -r .\HOST\requirements.txt
```

启动 GUI：

```powershell
python .\HOST\pid_autotune_gui.py
```

也可以双击 `HOST/start_autotune.bat`。

常用只读或安全命令：

```powershell
python .\HOST\pid_lab_cli.py ports
python .\HOST\pid_lab_cli.py diagnose --port COM12
python .\HOST\pid_lab_cli.py params --port COM12
python .\HOST\pid_lab_cli.py stop --port COM12
python .\HOST\pid_lab_cli.py profile --port COM12 --name light
python .\HOST\pid_lab_cli.py profile --port COM12 --name gimbal
python .\HOST\pid_lab_cli.py restore-v4 --port COM12
```

方框命令会驱动车辆，必须先清空并封闭场地：

```powershell
python .\HOST\pid_lab_cli.py square --port COM12 --speed 120 --laps 1 --turn-distance 98 --track-safe
```

重云台初测不要直接运行 `wheel-tune` 或 `line-tune`。先完成第 6 节的机械、供电和低速数据检查。

## 8. 工程保留结构

- `main.c`、`app_config.h`：主程序和默认参数；
- `LAB/`：命令协议、轮速闭环、V4 循迹和方框状态机；
- `MOTOR/`、`ENCODER/`、`SENSOR/`、`MPU/`、`SERIAL/`：底层硬件模块；
- `ESP8266_BRIDGE/`：PC 与车端的 ESP8266/串口桥；
- `HOST/pid_autotune_gui.py`：GUI 与自动调参核心；
- `HOST/pid_lab_cli.py`：无界面诊断、回读、恢复和方框记录；
- `HOST/ground_straight_test.py`：强制载荷元数据、GIMBAL 档回读和 120→160→200 门控的落地直线采集；
- `HOST/imu_motor_interference_test.py`、`HOST/bridge_stress_test.py`：载荷与供电改变后仍有价值的诊断工具；
- `HOST/test_pid_autotune.py`：上位机回归测试；
- `build_mspm0_hex.ps1`：MSPM0 无警告构建脚本；
- `docs/HARDWARE_REFERENCES.md`：硬件资料索引；
- `Debug/`：保留当前双档 HEX、修改前 V4-TurnGuard 回退件和精确 V4 回退件；其他内容可由构建脚本重新生成。

已清理内容包括：过时调参冠军文件、已否决循迹试验日志、重复试跑、旧诊断 HEX、旧别名 HEX、对象文件、链接中间文件、SysConfig 临时输出和 Python 缓存。不要把这些历史结果重新当作当前参数来源。

## 9. 构建与自检

在工程根目录执行：

```powershell
powershell -ExecutionPolicy Bypass -File .\build_mspm0_hex.ps1
python -m py_compile .\HOST\pid_autotune_gui.py .\HOST\pid_lab_cli.py .\HOST\ground_straight_test.py
python -m unittest discover -s .\HOST -p "test_*.py"
```

正常构建只更新 `Debug/pid_lab_mspm0.hex`，不改动两个回退件。重新构建会更新当前 HEX，因此需要重新记录大小和 SHA-256；`pid_lab_mspm0_v4_turnguard.hex` 和 `pid_lab_mspm0_v4_exact.hex` 都不应被构建脚本覆盖。构建脚本以 `-Wall -Wextra -Werror` 强制 warning 失败；本次构建已通过 24 个上位机测试和无警告编译/链接。

## 10. 新对话直接使用的开场提示

```text
请先完整阅读 README.md，再检查当前源码和保留日志。工程唯一基线是 V4：
Debug/pid_lab_mspm0_v4_exact.hex 是截图中的精确 V4；
Debug/pid_lab_mspm0_v4_turnguard.hex 是修改前的 V4 直线循迹原样加最小 50° TurnGuard 回退件；
Debug/pid_lab_mspm0.hex 保持相同控制算法，只增加 Flash V3 LIGHT/GIMBAL 双档和载荷日志入口。
轻载 V4 已在 300/340/380 mm/s 完成过方框，但安装很重的云台后已经不能正常工作。
不要恢复已否决的中间循迹算法，不要覆盖轻载 V4 参数，不要先盲调 LINEKP/LINEKD。
请先使用当前工具记录云台质量、重心、供电和灰度板高度，从 120 mm/s 的 V4_GIMBAL 落地直线辨识开始；先审阅轮速日志，再修改 GIMBAL 槽，轮速稳定后才适配循迹和转弯。第 8 路灰度继续屏蔽。
每次修改都要保留可回退 HEX、明确 SHA-256，并先跑上位机测试和固件无警告构建。
```

"""不接实车即可运行的上位机协议与算法回归测试。"""

from __future__ import annotations

import queue
import io
import tempfile
import threading
import unittest
from pathlib import Path
from contextlib import redirect_stderr
from unittest import mock

import pid_autotune_gui as gui
import pid_lab_cli as cli
import ground_straight_test as ground


class FakeLink:
    def __init__(self, responder=None) -> None:
        self.data_queue: queue.Queue[str] = queue.Queue()
        self.display_queue: queue.Queue[str] = queue.Queue()
        self.commands: list[str] = []
        self.responder = responder
        self.connected = True

    def send(self, command: str) -> None:
        self.commands.append(command)
        if self.responder is not None:
            for line in self.responder(command, self.commands.count(command)):
                self.data_queue.put(line)

    def drain_data(self) -> None:
        while True:
            try:
                self.data_queue.get_nowait()
            except queue.Empty:
                return

    def set_trace_path(self, _path: Path | None) -> None:
        return


def make_tuner(link: FakeLink) -> gui.AutoTuner:
    return gui.AutoTuner(link, queue.Queue(), lambda: None)  # type: ignore[arg-type]


class ProtocolTests(unittest.TestCase):
    def test_parameter_report_parser_and_stable_display(self) -> None:
        values = gui.parse_parameter_report(
            "PARAM,x1000,RKP,500,LKP,350,LINEKP,8250,BAD,nope"
        )
        self.assertEqual(
            values, {"RKP": 500, "LKP": 350, "LINEKP": 8250}
        )
        self.assertEqual(
            gui.format_parameters(values),
            "LKP=350  RKP=500  LINEKP=8250",
        )

    def test_set_retries_after_lost_ack(self) -> None:
        def respond(command: str, attempt: int) -> list[str]:
            if command.startswith("SET ") and attempt == 2:
                _, name, value, token = command.split()
                return [f"SA,{token},{name},{value}"]
            return []

        link = FakeLink(respond)
        tuner = make_tuner(link)
        with mock.patch.object(gui, "COMMAND_ACK_TIMEOUT", 0.01):
            tuner._send_set("LKP", 150)
        self.assertEqual(len(link.commands), 2)
        self.assertEqual(link.commands[0], link.commands[1])

    def test_profile_selection_requires_flash_v3_readback(self) -> None:
        def respond(command: str, _attempt: int) -> list[str]:
            if command == "PROFILE GIMBAL":
                return ["OK PROFILE GIMBAL FLASH 3"]
            if command == "PARAM":
                return [
                    "PARAM,x1000,PROFILE,1,FLASHVER,3,LKP,350,LINEKP,6750"
                ]
            return []

        tuner = make_tuner(FakeLink(respond))
        values = tuner._select_profile("gimbal")
        self.assertEqual(values["PROFILE"], 1)
        self.assertEqual(values["FLASHVER"], 3)

    def test_tune_result_is_recovered_with_tuneget(self) -> None:
        state: dict[str, str] = {}

        def respond(command: str, attempt: int) -> list[str]:
            if command.startswith("TUNEOPEN "):
                _, wheel, pwm, _, token = command.split()
                state.update(wheel=wheel, pwm=pwm, token=token)
                # 第一个启动 ACK 丢失；相同 token 重发后固件只补 ACK。
                return [f"TA,{token},O,{wheel}"] if attempt == 2 else []
            if command.startswith("TUNEGET "):
                return [
                    f"TO,{state['token']},{state['wheel']},{state['pwm']},"
                    "310,40,340,0"
                ]
            return []

        link = FakeLink(respond)
        tuner = make_tuner(link)
        with mock.patch.object(gui, "COMMAND_ACK_TIMEOUT", 0.01):
            result = tuner._run_tune_transaction(
                "TUNEOPEN L 100 1 42", 42, "L", "O", "TO,42,L,", 1
            )
        self.assertEqual(result, "TO,42,L,100,310,40,340,0")
        self.assertEqual(link.commands.count("TUNEOPEN L 100 1 42"), 2)
        self.assertIn("TUNEGET 42", link.commands)

    def test_protocol_handshake_checks_hardware_scale(self) -> None:
        def respond(command: str, _attempt: int) -> list[str]:
            if command.startswith("HELLO "):
                token = command.split()[1]
                return [
                    f"HELLO,{token},2,STBY,HIGH,ENCODER_MM_X1000,580,"
                    "SAMPLE_MS,10"
                ]
            return []

        tuner = make_tuner(FakeLink(respond))
        tuner._verify_connection()
        self.assertEqual(tuner.protocol_info["version"], 2)
        self.assertEqual(tuner.protocol_info["encoder_sample_ms"], 10)

    def test_runtime_snapshot_and_cancelled_rollback(self) -> None:
        def respond(command: str, _attempt: int) -> list[str]:
            if command == "PARAM":
                return [
                    "PARAM,x1000,LKP,350,LKI,200,RKP,500,RKI,100,"
                    "LFF,461,RFF,434,LMIN,31,RMIN,27,SYNC,1000,"
                    "BIAS,50,LINEKP,6000,LINEKD,2500,TURNDIST,95"
                ]
            if command == "STOP":
                return ["OK STOP"]
            if command.startswith("SET "):
                _, name, value, token = command.split()
                return [f"SA,{token},{name},{value}"]
            return []

        link = FakeLink(respond)
        tuner = make_tuner(link)
        snapshot = tuner._read_parameters()
        self.assertEqual(snapshot["LINEKP"], 6000)
        self.assertEqual(snapshot["LINEKD"], 2500)

        tuner.cancel_event.set()
        tuner._restore_runtime_parameters(
            snapshot, gui.LINE_RUNTIME_PARAMETERS
        )
        self.assertTrue(tuner.cancel_event.is_set())
        self.assertTrue(any(
            command.startswith("SET LINEKP 6000 ")
            for command in link.commands
        ))
        self.assertTrue(any(
            command.startswith("SET LINEKD 2500 ")
            for command in link.commands
        ))
        self.assertTrue(any(
            command.startswith("SET TURNDIST 95 ")
            for command in link.commands
        ))
        self.assertFalse(any(command.startswith("SAVE")
                             for command in link.commands))

    def test_square_rollback_restores_ram_without_save(self) -> None:
        class SquareTuner:
            def __init__(self) -> None:
                self.restored = None

            def _restore_runtime_parameters(self, snapshot, names) -> None:
                self.restored = (snapshot, names)

        app = gui.App.__new__(gui.App)
        app.square_transaction_lock = threading.RLock()
        app.square_parameter_snapshot = {"TURNFAST": 185}
        app.tuner = SquareTuner()
        message = app._rollback_square_parameters()
        self.assertIn("host SAVE not confirmed", message)
        self.assertEqual(
            app.tuner.restored,
            ({"TURNFAST": 185}, gui.TURN_RUNTIME_PARAMETERS),
        )
        self.assertIsNone(app.square_parameter_snapshot)

    def test_square_commits_only_in_success_finalizer(self) -> None:
        link = FakeLink()
        link.data_queue.put("SQUARE DONE,4")

        class SquareTuner:
            def __init__(self) -> None:
                self.cancel_event = threading.Event()
                self.saved = False

            def _save_parameters(self) -> None:
                self.assert_queue_empty()
                self.saved = True

            def assert_queue_empty(self) -> None:
                if not link.data_queue.empty():
                    raise AssertionError("stale SQUARE DONE was not drained")

        app = gui.App.__new__(gui.App)
        app.square_transaction_lock = threading.RLock()
        app.square_parameter_snapshot = {"TURNFAST": 185}
        app.tuner = SquareTuner()
        app.link = link
        app._finalize_square_success("SQUARE DONE,4")
        self.assertTrue(app.tuner.saved)
        self.assertIsNone(app.square_parameter_snapshot)
        self.assertEqual(
            app.link.display_queue.get_nowait(),
            "HOST SQUARE COMMITTED,SQUARE DONE,4",
        )


class AlgorithmTests(unittest.TestCase):
    def test_firmware_turn_capture_has_minimum_yaw_guard(self) -> None:
        source = (
            Path(__file__).resolve().parent.parent / "LAB" / "lab_ctrl.c"
        ).read_text(encoding="utf-8")
        self.assertIn(
            "#define LAB_TURN_LINE_CAPTURE_MIN_YAW_X10 500", source
        )
        self.assertIn(
            "g_turnYawX10 >= LAB_TURN_LINE_CAPTURE_MIN_YAW_X10", source
        )
        self.assertIn("lineCaptureReady = 1U", source)
        self.assertIn(
            "g_turnCapturedByLine = lineCaptureReady", source
        )

    def test_line_mask_error_matches_firmware_and_masks_sensor_8(self) -> None:
        self.assertEqual(gui.line_error_from_mask(24), (0, True))
        self.assertEqual(gui.line_error_from_mask(48), (6, True))
        self.assertEqual(gui.line_error_from_mask(24 | 0x80), (0, True))
        self.assertEqual(gui.line_error_from_mask(0), (0, False))

    def test_line_search_is_local_and_never_requires_zero_kd(self) -> None:
        self.assertEqual(
            gui.local_line_candidates(6750, 750, gui.LINE_KP_SAFE_RANGE),
            (6000, 6750, 7500),
        )
        kd_values = gui.local_line_candidates(
            2000, 500, gui.LINE_KD_SAFE_RANGE
        )
        self.assertEqual(kd_values, (1500, 2000, 2500))
        self.assertNotIn(0, kd_values)

    def test_line_preflight_rejects_off_center_mask_before_motion(self) -> None:
        def respond(command: str, _attempt: int) -> list[str]:
            if command == "SENSOR":
                return ["SENSOR,OK,48,0,93,4,48"]
            return []

        link = FakeLink(respond)
        tuner = make_tuner(link)
        with self.assertRaisesRegex(RuntimeError, "centered on the black line"):
            tuner._verify_centered_line_sensor()
        self.assertFalse(any(command.startswith("SQUARE")
                             for command in link.commands))

    def test_passive_candidate_sends_no_kick(self) -> None:
        def centered_sample(time_ms: int, corner: int = 0,
                            state: int = 0) -> str:
            return (
                f"LT,{time_ms},340,340,340,340,0,24,1,0,"
                f"{corner},{state},0"
            )

        def respond(command: str, _attempt: int) -> list[str]:
            if command.startswith("SET "):
                _, name, value, token = command.split()
                reply = [f"SA,{token},{name},{value}"]
                if name == "LINEKD":
                    time_ms = 800
                    for corner in range(4):
                        count = 12 if corner == 0 else 2
                        for _ in range(count):
                            reply.append(centered_sample(time_ms, corner))
                            time_ms += 20
                    reply.append(centered_sample(time_ms, 4, state=1))
                return reply
            return []

        link = FakeLink(respond)
        for index in range(gui.LINE_SWITCH_CENTER_SAMPLES):
            link.data_queue.put(centered_sample(600 + index * 20))
        tuner = make_tuner(link)
        with tempfile.TemporaryDirectory() as directory:
            tuner.session_dir = Path(directory)
            score, sample_count = tuner._run_square_line_candidate(
                6000, 2000, "passive", minimum_edge_samples=2
            )
        self.assertLess(score, 0.2)
        self.assertEqual(sample_count, 8)
        self.assertFalse(any(command.startswith("KICK")
                             for command in link.commands))

    def test_adaptive_feedforward_fit_brackets_target(self) -> None:
        tuner = make_tuner(FakeLink())

        def fake_transaction(
            _command: str, token: int, wheel: str, _kind: str,
            _prefix: str, _duration: int,
        ) -> str:
            pwm = int(_command.split()[2])
            speed = pwm * 3
            return f"TO,{token},{wheel},{pwm},{speed},40,{speed + 20},0"

        tuner._run_tune_transaction = fake_transaction  # type: ignore[method-assign]
        with tempfile.TemporaryDirectory() as directory:
            tuner.session_dir = Path(directory)
            min_pwm, ff = tuner._identify_feedforward("L")
        self.assertLessEqual(min_pwm, 2)
        self.assertTrue(325 <= ff <= 342)
        self.assertIn("L", tuner.feedforward_diagnostics)

    def test_compact_line_sample_parser(self) -> None:
        sample = gui.PidSample.parse("LT,100,280,280,275,282,-2,24,1,31,0,0,0")
        self.assertIsNotNone(sample)
        assert sample is not None
        self.assertEqual(sample.mode, "SQUARE")
        self.assertEqual(sample.right_speed, 282)
        self.assertEqual(sample.line_mask, 24)

    def test_line_score_penalizes_snake_and_control_jumps(self) -> None:
        def samples(snake: bool) -> list[gui.PidSample]:
            result: list[gui.PidSample] = []
            for index in range(120):
                if snake:
                    error = 12 if (index // 3) % 2 == 0 else -12
                    turn = 100 if error > 0 else -100
                else:
                    error = (0, 1, 0, -1)[index % 4]
                    turn = error * 2
                result.append(gui.PidSample(
                    time_ms=600 + index * 20,
                    mode="SQUARE",
                    left_target=360 + turn,
                    right_target=360 - turn,
                    left_speed=360 + turn,
                    right_speed=360 - turn,
                    left_pwm=0,
                    right_pwm=0,
                    left_error=0,
                    right_error=0,
                    count_diff=0,
                    line_error=error,
                    line_mask=24,
                    line_valid=1,
                ))
            return result

        stable_score = gui.AutoTuner._score_line(samples(False))
        snake_score = gui.AutoTuner._score_line(samples(True))
        self.assertLess(stable_score, 0.2)
        self.assertGreater(snake_score, stable_score + 2.0)

    def test_v5_score_rejects_far_tail_even_when_it_recovers(self) -> None:
        def full_lap(far: bool) -> list[gui.PidSample]:
            result: list[gui.PidSample] = []
            for corner in range(4):
                for index in range(50):
                    error = 18 if far and index < 10 else (
                        6 if not far and index < 2 else 0
                    )
                    turn = min(100, abs(error) * 4)
                    if error < 0:
                        turn = -turn
                    result.append(gui.PidSample(
                        time_ms=600 + (corner * 50 + index) * 20,
                        mode="SQUARE",
                        left_target=340 + turn,
                        right_target=340 - turn,
                        left_speed=340 + turn,
                        right_speed=340 - turn,
                        left_pwm=0,
                        right_pwm=0,
                        left_error=0,
                        right_error=0,
                        count_diff=0,
                        line_error=error,
                        line_mask=24,
                        line_valid=1,
                        corner_count=corner,
                    ))
            return result

        near_score = gui.AutoTuner._score_line(full_lap(False))
        far_score = gui.AutoTuner._score_line(full_lap(True))
        self.assertGreater(far_score, near_score + 0.5)


class CliTests(unittest.TestCase):
    def test_restore_v4_stops_saves_and_verifies_turn_baseline(self) -> None:
        tuner = mock.Mock()
        tuner._read_parameters.return_value = {
            "LINEKP": 6750,
            "LINEKD": 2000,
            "TURNDIST": 98,
            "FLASHVER": 3,
            "PROFILE": 1,
        }

        cli.restore_v4_baseline(tuner)

        tuner._verify_connection.assert_called_once_with()
        tuner._stop_reliably.assert_called_once_with()
        tuner._select_profile.assert_called_once_with("LIGHT")
        self.assertEqual(
            tuner._send_set.call_args_list,
            [
                mock.call("LINEKP", 6750),
                mock.call("LINEKD", 2000),
                mock.call("TURNDIST", 98),
            ],
        )
        tuner._save_parameters.assert_called_once_with()
        self.assertEqual(tuner._read_parameters.call_count, 2)

    def test_restore_line_stops_saves_and_verifies_stable_pair(self) -> None:
        tuner = mock.Mock()
        tuner._read_parameters.return_value = {
            "LINEKP": 6750,
            "LINEKD": 2000,
            "FLASHVER": 3,
            "PROFILE": 1,
        }

        cli.restore_stable_line(tuner)

        tuner._verify_connection.assert_called_once_with()
        tuner._stop_reliably.assert_called_once_with()
        tuner._select_profile.assert_called_once_with("LIGHT")
        self.assertEqual(
            tuner._send_set.call_args_list,
            [mock.call("LINEKP", 6750), mock.call("LINEKD", 2000)],
        )
        tuner._save_parameters.assert_called_once_with()
        self.assertEqual(tuner._read_parameters.call_count, 2)

    def test_archived_v4_without_profiles_remains_restorable(self) -> None:
        tuner = mock.Mock()
        tuner._read_parameters.return_value = {
            "LINEKP": 6750, "LINEKD": 2000, "TURNDIST": 98,
        }
        cli.restore_v4_baseline(tuner)
        tuner._select_profile.assert_not_called()
        tuner._save_parameters.assert_called_once_with()

    def test_motion_commands_require_safety_acknowledgement(self) -> None:
        with mock.patch.object(cli, "connect") as connect_mock:
            self.assertEqual(
                cli.main(["wheel-tune", "--port", "COM99"]), 2
            )
            self.assertEqual(
                cli.main(["line-tune", "--port", "COM99"]), 2
            )
            self.assertEqual(
                cli.main(["square", "--port", "COM99"]), 2
            )
        connect_mock.assert_not_called()

    def test_square_argument_validation(self) -> None:
        parser = cli.build_parser()
        args = parser.parse_args([
            "square", "--port", "COM1", "--track-safe",
            "--turn-fast", "120", "--turn-slow", "140",
        ])
        with self.assertRaisesRegex(ValueError, "turn-slow"):
            cli.validate_square(args)

    def test_line_result_summary_shows_champion_and_challenger(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            result_dir = Path(directory) / "line_20260715_120000"
            result_dir.mkdir()
            (result_dir / "line_tuned_params.json").write_text(
                '{"line_kp_x1000":8250,"line_kd_x1000":2250,'
                '"challenger":{"line_kp_x1000":6750,'
                '"line_kd_x1000":3500},'
                '"selection_reason":"incumbent kept"}',
                encoding="utf-8",
            )
            summary = gui.load_line_result_summary(Path(directory))
        self.assertIn("冠军 LINEKP=8250, LINEKD=2250", summary)
        self.assertIn("挑战者 LINEKP=6750, LINEKD=3500", summary)
        self.assertIn("incumbent kept", summary)


class GroundStraightMetadataTests(unittest.TestCase):
    @staticmethod
    def valid_args() -> list[str]:
        return [
            "COM99",
            "--base-mass-g", "500",
            "--gimbal-mass-g", "300",
            "--mounting-mass-g", "20",
            "--total-mass-g", "820",
            "--gimbal-cog-height-mm", "145",
            "--gimbal-cog-forward-mm", "12",
            "--gimbal-cog-left-mm", "-3",
            "--battery-idle-v", "8.1",
            "--battery-startup-v", "7.5",
            "--sensor-height-mm", "9.5",
            "--sensor-height-light-mm", "11",
            "--wheel-load", "balanced",
            "--wheel-slip-observed", "none",
            "--confirm-gimbal-mount-rigid",
            "--confirm-ground-clear",
            "--confirm-observer-ready",
        ]

    def test_120_mmps_metadata_is_complete_and_balanced(self) -> None:
        args = ground.parse_args(self.valid_args())
        metadata = ground.build_load_metadata(args)
        self.assertEqual(args.speed, 120)
        self.assertEqual(metadata["control_profile"], "V4_GIMBAL")
        self.assertEqual(metadata["mass_g"]["balance_error"], 0)
        self.assertAlmostEqual(metadata["power_v"]["startup_drop"], 0.6)

    def test_higher_speed_requires_preceding_log_review(self) -> None:
        with redirect_stderr(io.StringIO()):
            with self.assertRaises(SystemExit):
                ground.parse_args(self.valid_args() + ["--speed", "160"])

    def test_unknown_measurements_are_explicitly_recorded(self) -> None:
        args = ground.parse_args([
            "COM99",
            "--allow-unknown-measurements",
            "--wheel-load", "balanced",
            "--wheel-slip-observed", "none",
            "--confirm-gimbal-mount-rigid",
            "--confirm-ground-clear",
            "--confirm-observer-ready",
            "--notes", "separate battery; stabilized; center-forward COG",
        ])
        metadata = ground.build_load_metadata(args)
        self.assertEqual(metadata["measurement_status"],
                         "partial_unknowns_allowed")
        self.assertIsNone(metadata["mass_g"]["total_measured"])
        self.assertIsNone(metadata["power_v"]["startup_drop"])


if __name__ == "__main__":
    unittest.main()
